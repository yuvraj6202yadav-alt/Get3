(function(){
  if(window.pywebview&&window.pywebview.api) return;
  var api=new Proxy({},{get:function(t,n){
    if(typeof n!=='string'||n==='then') return undefined;
    return function(){
      var a=[].slice.call(arguments);
      return new Promise(function(res){
        var r=null;
        try{ r=window.Get3Bridge.call(n,JSON.stringify(a)); }catch(e){}
        try{ res(r?JSON.parse(r):null); }catch(e){ res(null); }
      });
    };
  }});
  window.pywebview={api:api};
  setTimeout(function(){ try{ window.dispatchEvent(new Event('pywebviewready')); }catch(e){} },0);
})();
