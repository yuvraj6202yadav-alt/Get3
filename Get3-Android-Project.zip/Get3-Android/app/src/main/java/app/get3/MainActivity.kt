package app.get3

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Get3 for Android - port of the Python/pywebview app.
 * Home screen (assets/home.html) and the floating bolt overlay (assets/overlay.js)
 * are the same as the desktop version; the Python Api class is re-written here.
 */
class MainActivity : Activity() {

    companion object {
        const val MOBILE_UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        const val HOME_BASE = "https://get3.app/home"
        const val REQ_FILE = 1001
    }

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private val lock = Any()

    private var homeHtml = ""
    private var overlayJs = ""
    private var shimJs = ""
    private var builtin = JSONArray()
    private var suggested = JSONArray()
    private var custom = JSONArray()
    private var recents = JSONArray()

    private var atHome = true
    private var pending: String? = null
    private var navId = 0
    private var injected = false
    private var clearHistoryNext = false

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null

    // ------------------------------------------------------------ lifecycle
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("get3", MODE_PRIVATE)

        shimJs = readAsset("shim.js")
        overlayJs = readAsset("overlay.js")
        val raw = readAsset("home.html")
        val i = raw.indexOf("<head>") + 6
        homeHtml = raw.substring(0, i) + "<script>" + shimJs + "</script>" + raw.substring(i)

        val plat = JSONObject(readAsset("platforms.json"))
        builtin = plat.getJSONArray("builtin")
        suggested = plat.getJSONArray("suggested")
        loadData()

        root = FrameLayout(this)
        web = WebView(this)
        web.setBackgroundColor(0xFFFFFFFF.toInt())
        root.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.userAgentString = MOBILE_UA
        s.setSupportMultipleWindows(false)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.allowFileAccess = false
        s.allowContentAccess = false

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)

        web.addJavascriptInterface(Bridge(), "Get3Bridge")
        web.webViewClient = client
        web.webChromeClient = chrome
        web.setDownloadListener { url, _, _, _, _ ->
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: Exception) {
            }
        }

        showHome()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        try {
            web.destroy()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) {
            hideCustom()
            return
        }
        if (atHome) {
            @Suppress("DEPRECATION")
            super.onBackPressed()
            return
        }
        if (web.canGoBack()) web.goBack() else goHomeAction(null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILE) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    // ------------------------------------------------------------ web clients
    private val client = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url
            val sch = (u.scheme ?: "").lowercase()
            if (sch == "http" || sch == "https") return false
            if (sch == "mailto" || sch == "tel" || sch == "sms") {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                }
            }
            return true // block intent:, market:, app deep links etc.
        }

        override fun onPageFinished(view: WebView, url: String?) {
            if (clearHistoryNext) {
                clearHistoryNext = false
                view.clearHistory()
            }
            if (atHome) return
            val u = url ?: ""
            if ((u.startsWith("http://") || u.startsWith("https://")) && !u.startsWith(HOME_BASE)) {
                injectOverlay()
            } else {
                failToHome()
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame && !atHome) failToHome()
        }
    }

    private val chrome = object : WebChromeClient() {
        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCb = callback
            root.addView(
                view,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            web.visibility = View.GONE
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }

        override fun onHideCustomView() {
            hideCustom()
        }

        override fun onShowFileChooser(
            webView: WebView?,
            callback: ValueCallback<Array<Uri>>?,
            params: FileChooserParams?
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = callback
            return try {
                @Suppress("DEPRECATION")
                startActivityForResult(params!!.createIntent(), REQ_FILE)
                true
            } catch (e: Exception) {
                fileCb = null
                false
            }
        }
    }

    private fun hideCustom() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        web.visibility = View.VISIBLE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        customCb?.onCustomViewHidden()
        customCb = null
    }

    // ------------------------------------------------------------ navigation
    private fun showHome() {
        clearHistoryNext = true
        ui.post {
            web.stopLoading()
            web.loadDataWithBaseURL(HOME_BASE, homeHtml, "text/html", "utf-8", null)
        }
    }

    private fun go(url: String) {
        atHome = false
        navId++
        injected = false
        clearHistoryNext = true
        val nid = navId
        ui.post { web.loadUrl(url) }
        ui.postDelayed({
            // site never finished loading (offline / blocked): back to Home
            if (nid == navId && !atHome && !injected) failToHome()
        }, 30000)
    }

    private fun failToHome() {
        atHome = true
        pending = "offline"
        navId++
        showHome()
    }

    private fun injectOverlay() {
        val plats = JSONArray()
        val all = allPlatforms()
        for (i in 0 until all.length()) {
            val p = all.getJSONObject(i)
            plats.put(
                JSONObject()
                    .put("id", p.optString("id"))
                    .put("name", p.optString("name"))
                    .put("url", p.optString("url"))
                    .put("color", p.optString("color", "#1D4ED8"))
            )
        }
        val data = JSONObject().put("platforms", plats).toString()
        val js = shimJs + "\n" + overlayJs.replace("__DATA__", data)
        injected = true
        web.evaluateJavascript(js, null)
    }

    // ------------------------------------------------------------ storage
    private fun readAsset(name: String): String =
        assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun loadData() {
        val saved = try {
            JSONArray(prefs.getString("custom", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val clean = JSONArray()
        for (i in 0 until saved.length()) {
            val c = saved.optJSONObject(i) ?: continue
            val name = sanitizeName(c.optString("name"))
            val url = normalizeUrl(c.optString("url"))
            if (name.isNotEmpty() && url != null && c.optString("id").isNotEmpty()) {
                c.put("name", name)
                c.put("url", url)
                c.put("builtin", false)
                clean.put(c)
            }
        }
        custom = clean
        recents = try {
            JSONArray(prefs.getString("recents", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun save() {
        prefs.edit()
            .putString("custom", custom.toString())
            .putString("recents", recents.toString())
            .apply()
    }

    private fun allPlatforms(): JSONArray {
        val out = JSONArray()
        for (i in 0 until builtin.length()) out.put(JSONObject(builtin.getJSONObject(i).toString()))
        for (i in 0 until custom.length()) out.put(JSONObject(custom.getJSONObject(i).toString()))
        return out
    }

    private fun find(pid: String): JSONObject? {
        val a = allPlatforms()
        for (i in 0 until a.length()) {
            val p = a.getJSONObject(i)
            if (p.optString("id") == pid) return p
        }
        return null
    }

    private fun stateJson(): JSONObject {
        val plats = allPlatforms()
        val ids = HashSet<String>()
        for (i in 0 until plats.length()) ids.add(plats.getJSONObject(i).optString("id"))
        val rec = JSONArray()
        for (i in 0 until recents.length()) {
            val p = find(recents.optString(i))
            if (p != null) rec.put(p)
        }
        val sug = JSONArray()
        for (i in 0 until suggested.length()) {
            val s = suggested.getJSONObject(i)
            if (!ids.contains(s.optString("id"))) sug.put(JSONObject(s.toString()))
        }
        val st = JSONObject()
        st.put("platforms", plats)
        st.put("recents", rec)
        st.put("suggested", sug)
        st.put("pending", pending ?: JSONObject.NULL)
        pending = null
        return st
    }

    private fun record(pid: String) {
        val r = ArrayList<String>()
        r.add(pid)
        for (i in 0 until recents.length()) {
            val x = recents.optString(i)
            if (x != pid) r.add(x)
        }
        val out = JSONArray()
        for (x in r.take(6)) out.put(x)
        recents = out
        save()
    }

    private fun uniqueId(base: String): String {
        val used = HashSet<String>()
        val a = allPlatforms()
        for (i in 0 until a.length()) used.add(a.getJSONObject(i).optString("id"))
        var pid = base
        var n = 2
        while (used.contains(pid)) {
            pid = base + "_" + n
            n++
        }
        return pid
    }

    // ------------------------------------------------------------ validation
    private fun sanitizeName(raw: String?): String {
        var s = (raw ?: "").replace(Regex("\\s+"), " ").trim()
        s = s.replace(Regex("(?U)[^\\w \\-.&]"), "").trim()
        return if (s.length > 24) s.substring(0, 24) else s
    }

    private fun slugify(name: String): String {
        val s = name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')
        return if (s.isEmpty()) "platform" else s
    }

    private fun normalizeUrl(raw: String?): String? {
        var s = (raw ?: "").replace(Regex("\\s+"), "")
        if (s.isEmpty()) return null
        val low = s.lowercase()
        val bad = listOf("javascript:", "data:", "file:", "vbscript:", "intent:", "blob:")
        if (bad.any { low.startsWith(it) }) return null
        if (!Regex("^[a-z][a-z0-9+.\\-]*://").containsMatchIn(low)) s = "https://$s"
        val u = try {
            Uri.parse(s)
        } catch (e: Exception) {
            return null
        }
        val sch = (u.scheme ?: return null).lowercase()
        if (sch != "http" && sch != "https") return null
        val host = u.host ?: return null
        if (!host.contains(".")) return null
        return s
    }

    private fun faviconFor(url: String): String {
        val host = Uri.parse(url).host ?: ""
        return "https://www.google.com/s2/favicons?domain=$host&sz=64"
    }

    // ------------------------------------------------------------ JS bridge
    inner class Bridge {
        @JavascriptInterface
        fun call(name: String, argsJson: String): String {
            val a = try {
                JSONArray(argsJson)
            } catch (e: Exception) {
                JSONArray()
            }
            val r = try {
                synchronized(lock) { dispatch(name, a) }
            } catch (e: Exception) {
                JSONObject().put("ok", false)
            }
            return r?.toString() ?: "null"
        }
    }

    private fun dispatch(name: String, a: JSONArray): JSONObject? = when (name) {
        "get_state" -> stateJson()
        "open_platform" -> openPlatform(a.optString(0))
        "open_url" -> openUrl(a.optString(0))
        "add_platform" -> addPlatform(a.optString(0), a.optString(1))
        "add_suggested" -> addSuggested(a.optString(0))
        "remove_platform" -> removePlatform(a.optString(0))
        "go_home" -> goHomeAction(if (a.isNull(0)) null else a.optString(0))
        "go_back" -> goBackAction()
        else -> JSONObject().put("ok", false)
    }

    private fun openPlatform(pid: String): JSONObject {
        val p = find(pid) ?: return JSONObject().put("ok", false)
        record(pid)
        go(p.optString("url"))
        return JSONObject().put("ok", true)
    }

    private fun openUrl(raw: String): JSONObject {
        if (!atHome) return JSONObject().put("ok", false)
        val text = raw.trim()
        var url: String? = null
        val low = text.lowercase()
        if (text.isNotEmpty() && !text.contains(" ") &&
            (text.contains(".") || low.startsWith("http://") || low.startsWith("https://"))
        ) {
            url = normalizeUrl(text)
        }
        if (url == null) url = "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8")
        go(url)
        return JSONObject().put("ok", true)
    }

    private fun addPlatform(rawName: String, rawUrl: String): JSONObject {
        if (!atHome) return JSONObject().put("ok", false).put("error", "Not available here.")
        val name = sanitizeName(rawName)
        val url = normalizeUrl(rawUrl)
        if (name.isEmpty()) return JSONObject().put("ok", false).put("error", "Enter a valid platform name.")
        if (url == null) {
            return JSONObject().put("ok", false)
                .put("error", "Enter a valid web address, e.g. twitter.com")
        }
        val pid = uniqueId(slugify(name))
        custom.put(
            JSONObject()
                .put("id", pid).put("name", name).put("url", url)
                .put("icon", faviconFor(url)).put("color", "#1D4ED8")
                .put("cat", "custom").put("builtin", false)
        )
        record(pid)
        save()
        go(url)
        return JSONObject().put("ok", true).put("id", pid).put("name", name)
    }

    private fun addSuggested(sid: String): JSONObject {
        if (!atHome) return stateJson()
        var s: JSONObject? = null
        for (i in 0 until suggested.length()) {
            if (suggested.getJSONObject(i).optString("id") == sid) s = suggested.getJSONObject(i)
        }
        if (s != null && find(sid) == null) {
            custom.put(
                JSONObject()
                    .put("id", s.optString("id")).put("name", s.optString("name"))
                    .put("url", s.optString("url")).put("icon", s.optString("icon"))
                    .put("color", s.optString("color")).put("cat", s.optString("cat"))
                    .put("builtin", false)
            )
            save()
        }
        return stateJson()
    }

    private fun removePlatform(pid: String): JSONObject {
        if (!atHome) return stateJson()
        val c = JSONArray()
        for (i in 0 until custom.length()) {
            val p = custom.getJSONObject(i)
            if (p.optString("id") != pid) c.put(p)
        }
        custom = c
        val r = JSONArray()
        for (i in 0 until recents.length()) {
            if (recents.optString(i) != pid) r.put(recents.optString(i))
        }
        recents = r
        save()
        return stateJson()
    }

    private fun goHomeAction(action: String?): JSONObject {
        atHome = true
        navId++
        pending = if (action == "add") "add" else null
        showHome()
        return JSONObject().put("ok", true)
    }

    private fun goBackAction(): JSONObject {
        ui.post {
            if (atHome) return@post
            if (web.canGoBack()) web.goBack() else goHomeAction(null)
        }
        return JSONObject().put("ok", true)
    }
}
