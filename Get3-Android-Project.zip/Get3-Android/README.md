# Get3 - Android version

Python (pywebview) app ka Android port. Home screen, bolt button aur platforms same hain.

## APK banane ka tareeka (GitHub, free, Android Studio nahi chahiye)
1. github.com par naya repository banao (name: get3).
2. Is zip ke SAARE files upload karo (`.github` folder ke saath).
3. Upload ke baad "Actions" tab -> "Build Get3 APK" automatically chalega (~5 min).
4. Khatam hone par repo ke "Releases" mein `Get3.apk` milegi. Wahi se download karo
   ya link share karo (repo public ho to koi bhi download kar sakta hai).
5. Phone mein APK kholo -> "Install unknown apps" allow karo -> Install.

## Android Studio se
Folder kholo -> Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk
